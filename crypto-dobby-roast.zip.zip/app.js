// Crypto Portfolio App with Dobby AI Roast
class CryptoPortfolioApp {
    constructor() {
        this.portfolio = [];
        this.priceData = {};
        this.isLoadingPrices = false;
        
        // API configuration
        this.coingeckoAPI = 'https://api.coingecko.com/api/v3';
        
        // Sample roast responses
        this.roastResponses = [
            "아, 또 다른 비트코인 맥시멀리스트가 자신을 워렌 버핏으로 착각하고 있네요! 당신의 포트폴리오는 외발자전거를 타는 사람이 발작을 일으키는 것보다 더 불균형해요. 트위터에서 떠도는 똑같은 세 개의 코인 말고 다양화를 좀 해보세요?",
            "보세요, 또 고점에서 산 진정한 디젠이군요. 당신의 포트폴리오 수익률이 너무 빨개서 교통 신호등 역할을 할 수 있겠어요. 하지만 적어도 일관성은 있네요... 일관성 있게 돈을 잃고 있다는 점에서요!",
            "높이 사서 절대 팔지 않는 당신의 인상적인 능력에 축하드려요! 당신의 다이아몬드 핸드는 콘크리트 장갑 같네요 - 무겁고 완전히 유연성이 없어요. '수익 실현'이 뭘 의미하는지 배울 때가 왔어요?",
            "와, 당신의 포트폴리오를 보니 FOMO의 교과서 사례네요! 모든 밈 코인과 하이프 토큰을 다 모으셨군요. 포켓몬이 아니라 암호화폐예요 - 다 모을 필요는 없다고요!",
            "당신의 투자 전략이 다트를 던지는 것보다 못하네요. 적어도 다트는 가끔 과녁을 맞히거든요. 리서치 좀 해보시고 유튜버 말만 듣지 마세요!",
            "축하해요! 당신은 '손절매'라는 단어를 사전에서 지운 것 같네요. -50% 손실을 '할인 구매 기회'라고 부르는 당신의 낙관주의는 정말 감동적이에요."
        ];
        
        this.coinMap = {
            'bitcoin': { symbol: 'BTC', name: 'Bitcoin' },
            'ethereum': { symbol: 'ETH', name: 'Ethereum' },
            'binancecoin': { symbol: 'BNB', name: 'Binance Coin' },
            'ripple': { symbol: 'XRP', name: 'Ripple' },
            'cardano': { symbol: 'ADA', name: 'Cardano' },
            'solana': { symbol: 'SOL', name: 'Solana' },
            'polkadot': { symbol: 'DOT', name: 'Polkadot' },
            'chainlink': { symbol: 'LINK', name: 'Chainlink' },
            'litecoin': { symbol: 'LTC', name: 'Litecoin' },
            'bitcoin-cash': { symbol: 'BCH', name: 'Bitcoin Cash' }
        };
        
        this.init();
    }
    
    init() {
        this.loadPortfolioFromStorage();
        this.bindEvents();
        this.updateUI();
        this.fetchPrices();
        
        // Auto refresh prices every 30 seconds
        setInterval(() => {
            this.fetchPrices();
        }, 30000);
    }
    
    bindEvents() {
        // Portfolio form submission
        document.getElementById('portfolio-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.addToPortfolio();
        });
        
        // Refresh prices button
        document.getElementById('refresh-prices').addEventListener('click', () => {
            this.fetchPrices();
        });
        
        // Get roast button
        document.getElementById('get-roast').addEventListener('click', () => {
            this.generateRoast();
        });
    }
    
    addToPortfolio() {
        const coinId = document.getElementById('coin-symbol').value;
        const quantity = parseFloat(document.getElementById('quantity').value);
        const purchasePrice = parseFloat(document.getElementById('purchase-price').value);
        
        if (!coinId || !quantity || !purchasePrice) {
            alert('모든 필드를 올바르게 입력해주세요.');
            return;
        }
        
        const coinInfo = this.coinMap[coinId];
        if (!coinInfo) {
            alert('유효하지 않은 코인입니다.');
            return;
        }
        
        // Check if coin already exists in portfolio
        const existingIndex = this.portfolio.findIndex(item => item.coinId === coinId);
        
        if (existingIndex !== -1) {
            // Update existing holding
            const existing = this.portfolio[existingIndex];
            const totalQuantity = existing.quantity + quantity;
            const totalValue = (existing.quantity * existing.purchasePrice) + (quantity * purchasePrice);
            const avgPrice = totalValue / totalQuantity;
            
            this.portfolio[existingIndex] = {
                ...existing,
                quantity: totalQuantity,
                purchasePrice: avgPrice
            };
        } else {
            // Add new holding
            this.portfolio.push({
                coinId,
                symbol: coinInfo.symbol,
                name: coinInfo.name,
                quantity,
                purchasePrice,
                currentPrice: 0
            });
        }
        
        this.savePortfolioToStorage();
        this.updateUI();
        this.fetchPrices();
        
        // Reset form
        document.getElementById('portfolio-form').reset();
        
        // Enable roast button if portfolio has items
        document.getElementById('get-roast').disabled = this.portfolio.length === 0;
    }
    
    removeFromPortfolio(index) {
        if (confirm('이 항목을 포트폴리오에서 제거하시겠습니까?')) {
            this.portfolio.splice(index, 1);
            this.savePortfolioToStorage();
            this.updateUI();
            
            // Disable roast button if portfolio is empty
            document.getElementById('get-roast').disabled = this.portfolio.length === 0;
        }
    }
    
    async fetchPrices() {
        if (this.portfolio.length === 0) return;
        
        this.showLoadingState();
        
        try {
            const coinIds = this.portfolio.map(item => item.coinId).join(',');
            const response = await fetch(
                `${this.coingeckoAPI}/simple/price?ids=${coinIds}&vs_currencies=usd`
            );
            
            if (!response.ok) {
                throw new Error('가격 정보를 가져올 수 없습니다.');
            }
            
            const data = await response.json();
            
            // Update portfolio with current prices
            this.portfolio.forEach(item => {
                if (data[item.coinId] && data[item.coinId].usd) {
                    item.currentPrice = data[item.coinId].usd;
                }
            });
            
            this.priceData = data;
            this.savePortfolioToStorage();
            this.updateUI();
            
        } catch (error) {
            console.error('Error fetching prices:', error);
            this.showError('가격 정보를 가져오는데 실패했습니다. 잠시 후 다시 시도해주세요.');
        }
        
        this.hideLoadingState();
    }
    
    updateUI() {
        this.renderPortfolioTable();
        this.updateMetrics();
    }
    
    renderPortfolioTable() {
        const portfolioTable = document.getElementById('portfolio-table');
        const portfolioRows = document.getElementById('portfolio-rows');
        const emptyState = document.getElementById('portfolio-empty');
        
        if (this.portfolio.length === 0) {
            portfolioTable.classList.add('hidden');
            emptyState.classList.remove('hidden');
            return;
        }
        
        portfolioTable.classList.remove('hidden');
        emptyState.classList.add('hidden');
        
        portfolioRows.innerHTML = '';
        
        this.portfolio.forEach((item, index) => {
            const currentValue = item.quantity * item.currentPrice;
            const investedValue = item.quantity * item.purchasePrice;
            const pnl = currentValue - investedValue;
            const pnlPercentage = investedValue > 0 ? (pnl / investedValue) * 100 : 0;
            
            const row = document.createElement('div');
            row.className = 'table-row';
            row.innerHTML = `
                <div class="table-cell" data-label="코인">
                    <div class="coin-info">
                        <div class="coin-icon">${item.symbol.charAt(0)}</div>
                        <div>
                            <div class="coin-name">${item.name}</div>
                            <div class="coin-symbol">${item.symbol}</div>
                        </div>
                    </div>
                </div>
                <div class="table-cell" data-label="수량">${item.quantity.toFixed(8)}</div>
                <div class="table-cell" data-label="구매가">$${item.purchasePrice.toFixed(2)}</div>
                <div class="table-cell" data-label="현재가">$${item.currentPrice.toFixed(2)}</div>
                <div class="table-cell ${pnl >= 0 ? 'pnl-positive' : 'pnl-negative'}" data-label="손익">
                    $${pnl.toFixed(2)} (${pnlPercentage.toFixed(1)}%)
                </div>
                <div class="table-cell" data-label="액션">
                    <button class="btn btn--danger" onclick="app.removeFromPortfolio(${index})">삭제</button>
                </div>
            `;
            
            portfolioRows.appendChild(row);
        });
    }
    
    updateMetrics() {
        let totalInvested = 0;
        let currentValue = 0;
        
        this.portfolio.forEach(item => {
            totalInvested += item.quantity * item.purchasePrice;
            currentValue += item.quantity * item.currentPrice;
        });
        
        const totalPnL = currentValue - totalInvested;
        const totalPnLPercentage = totalInvested > 0 ? (totalPnL / totalInvested) * 100 : 0;
        
        document.getElementById('total-invested').textContent = `$${totalInvested.toFixed(2)}`;
        document.getElementById('current-value').textContent = `$${currentValue.toFixed(2)}`;
        
        const pnlElement = document.getElementById('total-pnl');
        pnlElement.textContent = `$${totalPnL.toFixed(2)} (${totalPnLPercentage.toFixed(1)}%)`;
        pnlElement.className = `metric-value ${totalPnL >= 0 ? 'text-positive' : 'text-negative'}`;
    }
    
    generateRoast() {
        if (this.portfolio.length === 0) return;
        
        const roastContent = document.getElementById('roast-content');
        const roastLoading = document.getElementById('roast-loading');
        const getRoastBtn = document.getElementById('get-roast');
        
        // Show loading state
        roastContent.classList.add('hidden');
        roastLoading.classList.remove('hidden');
        getRoastBtn.disabled = true;
        
        // Simulate API delay
        setTimeout(() => {
            const randomRoast = this.roastResponses[Math.floor(Math.random() * this.roastResponses.length)];
            
            roastLoading.classList.add('hidden');
            roastContent.classList.remove('hidden');
            
            // Typewriter effect
            this.typewriterEffect(roastContent, randomRoast);
            getRoastBtn.disabled = false;
            
        }, 2000);
    }
    
    typewriterEffect(element, text) {
        element.innerHTML = '';
        const p = document.createElement('p');
        p.className = 'roast-text';
        element.appendChild(p);
        
        let i = 0;
        const timer = setInterval(() => {
            p.textContent += text.charAt(i);
            i++;
            
            if (i > text.length) {
                clearInterval(timer);
            }
        }, 50);
    }
    
    showLoadingState() {
        document.getElementById('portfolio-loading').classList.remove('hidden');
        this.isLoadingPrices = true;
    }
    
    hideLoadingState() {
        document.getElementById('portfolio-loading').classList.add('hidden');
        this.isLoadingPrices = false;
    }
    
    showError(message) {
        // Simple error display - could be enhanced with a proper toast system
        alert(message);
    }
    
    savePortfolioToStorage() {
        try {
            localStorage.setItem('crypto-portfolio', JSON.stringify(this.portfolio));
        } catch (error) {
            console.error('Failed to save portfolio to storage:', error);
        }
    }
    
    loadPortfolioFromStorage() {
        try {
            const stored = localStorage.getItem('crypto-portfolio');
            if (stored) {
                this.portfolio = JSON.parse(stored);
                // Ensure all items have required properties
                this.portfolio = this.portfolio.filter(item => 
                    item.coinId && item.symbol && item.name && 
                    typeof item.quantity === 'number' && 
                    typeof item.purchasePrice === 'number'
                );
            }
        } catch (error) {
            console.error('Failed to load portfolio from storage:', error);
            this.portfolio = [];
        }
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new CryptoPortfolioApp();
    
    // Add some sample data for demonstration (optional)
    if (window.location.search.includes('demo=true')) {
        setTimeout(() => {
            // Add sample Bitcoin holding
            document.getElementById('coin-symbol').value = 'bitcoin';
            document.getElementById('quantity').value = '0.1';
            document.getElementById('purchase-price').value = '45000';
            
            // Trigger add to portfolio
            const event = new Event('submit');
            document.getElementById('portfolio-form').dispatchEvent(event);
            
            // Add sample Ethereum holding after a short delay
            setTimeout(() => {
                document.getElementById('coin-symbol').value = 'ethereum';
                document.getElementById('quantity').value = '2.5';
                document.getElementById('purchase-price').value = '3000';
                
                const event2 = new Event('submit');
                document.getElementById('portfolio-form').dispatchEvent(event2);
            }, 1000);
        }, 2000);
    }
});

// Utility functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('ko-KR', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount);
}

function formatPercentage(value) {
    return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
}

// Error handling for global errors
window.addEventListener('error', (e) => {
    console.error('Global error:', e.error);
});

window.addEventListener('unhandledrejection', (e) => {
    console.error('Unhandled promise rejection:', e.reason);
    e.preventDefault();
});

// Export app for testing purposes
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CryptoPortfolioApp;
}